# OverPower-RD

Just one more OP mod for Mindustry...

In this mod I tried to make some unusual stuff, like HCryogen, that boosts any turret in 200 times, Meltdown ship, that shooting with slag and deal near 1000dps.


Not too OP?

Its not manual OP mod, where you can build anything for free (top turret costs 14000 titanium (anyway some stuff are costs almost nothing)), but all, what you will built will make very useful stuff.


changelog:

v1.3.2. Added new battery, turret "S.D.M.G." in sandbox, cuz why the hell no? Also added new ship and pad for it, shockmine and bridge conveyor. Scatter now can shoot obsidian;

v1.3.1. Added Obsidian, lava, foundry form, two factory. Wave can shoot the lava. Started working on the new turret;

v1.3. Added full liquid equipment and even more, repair laser now fully works, mass driver "Thrower", mend and overdrive projectors, new material: RadPhase fabric, it's smelter and RadReactor for it, new vault, new mech, new core: over9000, you can try to build it any time! Also fixed some minor bugs;

v1.2.3. Added conduit, Lancer bot and it's factory, full ru translation and duo now can shoot with pyromaniac;

v1.2.2. Added cultivator, Surger (wall), Wave now can shoot with hyper-cryo and Meltdown mech is now really melting all (with slag, meltdownLaser is not working like main bullet for mech);

v1.2.1. Added liquid pump, force projector, Igor-mech and Igor-pad, Jet fuel and power node;

v1.2. Added Rdill (Drill), two solid pumps, not working Repair point, thorium in separator with low chance and fixed some minor bugs;

v1.1. Added two turrets: Duo lancer and Mini death gun (mini meltdown), Deflector and Meltdown-mech with it's own pad;

v1.0. Added Pyromaniac (flammability 20000%) and Hyper cryogen (heat capacity 20000%), also mixers for both;


credits:

Anuken
For Mindustry, where we all can do things like that.

Founder
For his OP EX mod, that inspired me to make my OP mod.

Aleph0Birds
For Mind.Dust.Try mod, that give me some elements of code.

Whert
For WherTex mod, that helped me with code for translation

Mindustry Mod Create dev team
MMC is useful sometimes and it saving many time.


